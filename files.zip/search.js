document.addEventListener('DOMContentLoaded', function () {
    const searchForm = document.getElementById('search-form');
    const searchInput = document.getElementById('search-input');
    if (!searchForm) return;

    // Se já existir um termo de busca na URL (ex: vindo de produtos.html?busca=algo),
    // mantém o valor escrito na caixa de pesquisa.
    const params = new URLSearchParams(window.location.search);
    const buscaAtual = params.get('busca');
    if (buscaAtual && searchInput) {
        searchInput.value = buscaAtual;
    }

    searchForm.addEventListener('submit', function (e) {
        e.preventDefault();
        const termo = searchInput.value.trim();
        if (!termo) return;
        window.location.href = 'produtos.html?busca=' + encodeURIComponent(termo);
    });
});
